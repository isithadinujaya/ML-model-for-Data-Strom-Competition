import pandas as pd
import numpy as np

from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler, FunctionTransformer
from sklearn.ensemble import StackingClassifier
from sklearn.linear_model import LogisticRegressionCV
from sklearn.metrics import classification_report, roc_auc_score

import xgboost as xgb
import lightgbm as lgb
from catboost import CatBoostClassifier

from imblearn.pipeline import Pipeline as ImbPipeline
from imblearn.over_sampling import SVMSMOTE

# ─────────────────────────────────────────────
# 1) Load data & create binary target
# ─────────────────────────────────────────────
date_cols = ["year_month", "agent_join_month", "first_policy_sold_month"]

df = pd.read_csv(
    "train_with_weekly_values.csv",
    parse_dates=date_cols
)

df['latest_policy_count'] = (df['latest_policy_count'] > 0).astype(int)

# ─────────────────────────────────────────────
# 2) Split into X / y
# ─────────────────────────────────────────────
# keep the raw date columns in X for in-pipeline extraction
drop_cols = ['latest_policy_count']
X = df.drop(columns=drop_cols)
y = df['latest_policy_count']

# ─────────────────────────────────────────────
# 3) Identify column groups
# ─────────────────────────────────────────────
cat_cols = ["agent_code"]
num_cols = [c for c in X.columns
            if c not in cat_cols + date_cols]

# ─────────────────────────────────────────────
# 4) Train/test split
# ────────────────────────────
X_train, X_test, y_train, y_test = train_test_split(
    X, y,
    test_size=0.2,
    stratify=y,
    random_state=42
)

# ─────────────────────────────────────────────
# 5) Build date-feature extractor
#    - turns each date column into “year” & “month”
# ─────────────────────────────────────────────
def extract_year_month(X_dates):
    # X_dates: 2D array with columns in the same order as date_cols
    df_dates = pd.DataFrame(X_dates, columns=date_cols)
    feats = []
    for col in date_cols:
        feats.append(df_dates[col].dt.year.values.reshape(-1, 1))
        feats.append(df_dates[col].dt.month.values.reshape(-1, 1))
    return np.hstack(feats)

date_transformer = Pipeline([
    ("extract", FunctionTransformer(extract_year_month, validate=False)),
    ("scale", StandardScaler())
])

# ─────────────────────────────────────────────
# 6) Preprocessing pipelines
# ─────────────────────────────────────────────
numeric_transformer = StandardScaler()
categorical_transformer = OneHotEncoder(handle_unknown="ignore")

preprocessor = ColumnTransformer([
    ("num",   numeric_transformer,    num_cols),
    ("cat",   categorical_transformer,cat_cols),
    ("date",  date_transformer,       date_cols)
], remainder="drop")

# ─────────────────────────────────────────────
# 7) Define base classifiers & stacking ensemble
# ─────────────────────────────────────────────
# 1) After you define X_train, y_train (binary 0/1)
import numpy as np

n_pos = np.sum(y_train == 1)
n_neg = np.sum(y_train == 0)
scale = n_neg / n_pos

print(f"Negative: {n_neg}, Positive: {n_pos}, scale_pos_weight = {scale:.2f}")

xgb_model = xgb.XGBClassifier(
    objective="binary:logistic",
    scale_pos_weight=scale,
    max_depth=6,
    learning_rate=0.05,
    n_estimators=400,
    subsample=0.8,
    random_state=42,
    use_label_encoder=False,
    eval_metric="logloss"
)

lgb_model = lgb.LGBMClassifier(
    objective="binary",
    class_weight={0:1, 1:1/scale},
    max_depth=6,
    learning_rate=0.05,
    n_estimators=400,
    subsample=0.8,
    random_state=42
)

cat_model = CatBoostClassifier(
    loss_function="Logloss",
    auto_class_weights='Balanced',
    depth=6,
    learning_rate=0.05,
    iterations=400,
    verbose=0,
    random_seed=42
)

ensemble = StackingClassifier(
    estimators=[
        ("xgb", xgb_model),
        ("lgb", lgb_model),
        ("cat", cat_model)
    ],
    final_estimator=LogisticRegressionCV(),
    passthrough=True,
    n_jobs=1
)

# ─────────────────────────────────────────────
# 8) SMOTETomek pipeline & ratio sweep
# ─────────────────────────────────────────────
best_results = []

pipe = ImbPipeline([
    ("preproc",  preprocessor),
    ('smote', SVMSMOTE(random_state=42)),
    ("stack",    ensemble)
])

pipe.fit(X_train, y_train)
y_proba = pipe.predict_proba(X_test)[:,1]
y_preds = pipe.predict(X_test)

print(classification_report(y_test, y_preds, digits=3))
print("Test ROC-AUC:", roc_auc_score(y_test, y_proba))

# ─────────────────────────────────────────────
# 9) Load test data and make predictions
# ─────────────────────────────────────────────
test_df = pd.read_csv(
    "test_with_weekly_values.csv",
    parse_dates=date_cols
)

# Prepare test features (drop target if present, though it might not be)
X_test_final = test_df.drop(columns=['latest_policy_count'] if 'latest_policy_count' in test_df.columns else [])

# Predict on test dataset
y_pred_test = pipe.predict(X_test_final)

# Create output DataFrame
output_df = pd.DataFrame({
    'row_id': test_df['row_id'],
    'target_column': y_pred_test
})

# Save to CSV
output_df.to_csv('predictions.csv', index=False)

print("Predictions saved to 'predictions.csv'")