import pandas as pd

# Load the CSV
df = pd.read_csv("sorted_predictions.csv")  # Replace with your actual file name

# Count number of zeros in the 'target_column'
zero_count = (df['target_column'] == 0).sum()

print("Number of zeros in target_column:", zero_count)
