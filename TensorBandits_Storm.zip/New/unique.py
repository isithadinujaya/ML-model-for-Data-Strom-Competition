import pandas as pd

# Load the data (assuming it's actually a CSV in .py file)
df = pd.read_csv('train_storming_round_with_latest.csv')

# Count unique agent codes
unique_agents = df['agent_code'].nunique()

print("Total number of unique agents:", unique_agents)
