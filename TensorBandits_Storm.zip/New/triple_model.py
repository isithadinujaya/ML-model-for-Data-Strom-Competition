import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, StratifiedKFold
from sklearn.metrics import recall_score, precision_score, f1_score, classification_report, roc_auc_score
from sklearn.preprocessing import StandardScaler, OneHotEncoder, FunctionTransformer
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline as SklearnPipeline
from sklearn.ensemble import StackingClassifier
from imblearn.pipeline import Pipeline as ImbPipeline
from imblearn.combine import SMOTETomek
from xgboost import XGBClassifier
from lightgbm import LGBMClassifier
from catboost import CatBoostClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.base import BaseEstimator, ClassifierMixin

# ─────────────────────────────────────────────
# 1) Load data & create binary target (Training)
# ─────────────────────────────────────────────
date_cols = ["year_month", "agent_join_month", "first_policy_sold_month"]

df = pd.read_csv(
    "train_with_weekly_values.csv",
    parse_dates=date_cols
)

df['latest_policy_count'] = (df['latest_policy_count'] > 0).astype(int)

# ─────────────────────────────────────────────
# 2) Split into X / y (Training)
# ─────────────────────────────────────────────
drop_cols = ['latest_policy_count']
X = df.drop(columns=drop_cols)
y = df['latest_policy_count']

# ─────────────────────────────────────────────
# 3) Identify column groups
# ─────────────────────────────────────────────
cat_cols = ["agent_code"]
num_cols = [c for c in X.columns if c not in cat_cols + date_cols]

# ─────────────────────────────────────────────
# 4) Train/test split (Training)
# ────────────────────────────
X_train, X_test, y_train, y_test = train_test_split(
    X, y,
    test_size=0.2,
    stratify=y,
    random_state=42
)

# Calculate class imbalance ratio
class_counts = y_train.value_counts()
if len(class_counts) < 2:
    raise ValueError("y_train contains only one class. Check data balance.")
ratio = class_counts[1] / class_counts[0] if class_counts.index[0] == 0 else class_counts[0] / class_counts[1]
print(f"Class ratio (minority/majority): {ratio:.2f}")

# ─────────────────────────────────────────────
# 5) Build date-feature extractor
# ─────────────────────────────────────────────
def extract_year_month(X_dates):
    df_dates = pd.DataFrame(X_dates, columns=date_cols)
    feats = []
    for col in date_cols:
        df_dates[col] = df_dates[col].fillna(pd.Timestamp('2000-01-01'))
        feats.append(df_dates[col].dt.year.values.reshape(-1, 1))
        feats.append(df_dates[col].dt.month.values.reshape(-1, 1))
    return np.hstack(feats)

date_transformer = SklearnPipeline([
    ("extract", FunctionTransformer(extract_year_month, validate=False)),
    ("scale", StandardScaler())
])

# ─────────────────────────────────────────────
# 6) Preprocessing pipeline
# ─────────────────────────────────────────────
numeric_transformer = StandardScaler()
categorical_transformer = OneHotEncoder(handle_unknown="ignore", sparse_output=False)

preprocessor = ColumnTransformer([
    ("num", numeric_transformer, num_cols),
    ("cat", categorical_transformer, cat_cols),
    ("date", date_transformer, date_cols)
], remainder="drop")

# ─────────────────────────────────────────────
# 7) Define base models and stacking ensemble
# ─────────────────────────────────────────────
xgb = XGBClassifier(random_state=42, scale_pos_weight=ratio)
lgb = LGBMClassifier(random_state=42, class_weight='balanced')
cat = CatBoostClassifier(verbose=0, random_state=42, auto_class_weights='Balanced')

stacking_model = StackingClassifier(
    estimators=[("xgb", xgb), ("lgb", lgb), ("cat", cat)],
    final_estimator=LogisticRegression(),
    cv=StratifiedKFold(n_splits=5, shuffle=True, random_state=42),
    passthrough=True
)

# ─────────────────────────────────────────────
# 8) Threshold tuner
# ─────────────────────────────────────────────
class ThresholdTuner(BaseEstimator, ClassifierMixin):
    def __init__(self, base_model, threshold=0.5):
        self.base_model = base_model
        self.threshold = threshold

    def fit(self, X, y):
        self.base_model.fit(X, y)
        return self

    def predict(self, X):
        proba = self.base_model.predict_proba(X)[:, 1]  # Probability of class 1
        return (proba >= self.threshold).astype(int)

    def predict_proba(self, X):
        return self.base_model.predict_proba(X)

# ─────────────────────────────────────────────
# 9) Full pipeline
# ─────────────────────────────────────────────
pipeline = ImbPipeline([
    ("preproc", preprocessor),
    ("sampler", SMOTETomek(random_state=42)),
    ("model", ThresholdTuner(base_model=stacking_model, threshold=0.65))
])

# Fit the pipeline
pipeline.fit(X_train, y_train)

# ─────────────────────────────────────────────
# 10) Load and predict on test dataset
# ─────────────────────────────────────────────
# Load test dataset
test_df = pd.read_csv(
    "test_with_weekly_values.csv",
    parse_dates=date_cols
)

# Prepare test features (drop target if present, though it might not be)
X_test_final = test_df.drop(columns=['latest_policy_count'] if 'latest_policy_count' in test_df.columns else [])

# Predict on test dataset
y_pred_test = pipeline.predict(X_test_final)

# Create output DataFrame
output_df = pd.DataFrame({
    'row_id': test_df['row_id'],
    'target_column': y_pred_test
})

# Save to CSV
output_df.to_csv('predictions.csv', index=False)

# ─────────────────────────────────────────────
# 11) Evaluate on training test split (optional)
# ─────────────────────────────────────────────
y_pred = pipeline.predict(X_test)
y_proba = pipeline.predict_proba(X_test)[:, 1]

print("Classification Report (Training Test Split):")
print(classification_report(y_test, y_pred, digits=3))
print("Test ROC-AUC (Training Test Split):", roc_auc_score(y_test, y_proba))